
const all = {
    serviceUrl: "https://api.myjson.com/bins/lmod2",
}

export default all;