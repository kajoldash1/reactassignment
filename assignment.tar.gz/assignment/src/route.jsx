import React, { Component } from 'react';
import {
    HashRouter as Router,
    Route
} from 'react-router-dom';
import HomePageComp  from './component/homepage.jsx'





class RoutesComp extends Component {
    render() {
        return (
            <Router>
                <div>
                    <div>
                        <Route exact path="/" component={HomePageComp} />
                    </div>
                </div>
            </Router>
        );
    }
}
export default RoutesComp;
