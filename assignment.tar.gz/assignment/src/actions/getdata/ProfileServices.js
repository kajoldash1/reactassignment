import {ProfileServices} from '../../service/urlservice.js'
function getState(ProfileState){
    return{
            type:'PROFILE_STATE',
            ProfileState
    }
}

 export const GetProfileAction=()=>dispatch=>{
    let ProfileState = [];
    ProfileServices((data => {
            (data) ? ProfileState = data.data.looks : console.log('error in fetching data')
        console.log("readstateAction"+ ProfileState)
        dispatch(getState(ProfileState))
    }))
 }