import { GetProfileAction } from './getdata/ProfileServices.js'


export {
    GetProfileAction
}