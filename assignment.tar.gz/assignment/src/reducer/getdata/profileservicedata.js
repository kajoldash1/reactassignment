export default function ProfileReducer(state = { ProfileState:[]}, action)  {

    switch (action.type) {
        case 'PROFILE_STATE':
            return {
                ProfileState: action.ProfileState,
            }
        default:
            return state
    }

}