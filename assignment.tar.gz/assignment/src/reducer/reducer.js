import { combineReducers } from 'redux';
import ProfileReducer from './getdata/profileservicedata.js'


export default combineReducers({
    ProfileReducer
   
})