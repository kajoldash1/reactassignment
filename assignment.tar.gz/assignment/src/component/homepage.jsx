import React, { Component } from 'react';
import '../stylesheets/landingpage.css'
import $ from 'jquery'
import userimage from '../images/about4.png'
//import Testing from '../images/testing.jpg'

import * as action from '../actions/action.js'
import { connect } from 'react-redux'

const mapStateToProps = state => ({
    ProfileState: state.ProfileReducer.ProfileState,
})

const mapDispatchToProps = dispatch => ({
    fetchProfileData() {
        dispatch(
            action.GetProfileAction()
        )
    },
})


class HomePageComp extends Component {
    constructor(props) {
        super(props);
        this.state = {

        };


    }

    componentDidMount() {
        this.props.fetchProfileData()

    }

    render() {
        const { ProfileState } = this.props
        console.log(ProfileState)
        const height = $(window).height()
        return (
            <div className="col-sm-12 mainpage  " style={{ minHeight: height }}>
                <nav class="navbar navbar-inverse">
                    <div class="container-fluid" style={{background:"#bd0606"}}>
                        <div class="navbar-header">
                            <a class="navbar-brand" href="#" style={{color:"#fff" ,fontWeight:"600"}}>myBataz</a>
                        </div>
                        
                    </div>
                </nav>
                <div className="col-sm-12 container nopadding" >

                    <div className="row">
                        <div className="col-sm-1 offset-sm-3">
                            <div className="row">
                                <div className="col-sm-12" style={{ padding: "28px 20px" }}>
                                    <div className="img-circle">
                                        <img src={userimage} alt="" style={{ width: "100%", borderRadius: "50%" }} />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-sm-4" style={{marginTop:"40px"}}>
                            <div className="row">
                                <div className="col-sm-12" >
                                    <div lassName="col-sm-12" style={{fontSize:"16px",fontWeight:"600"}}>Kajol Dash</div>
                                    <div lassName="col-sm-12" style={{fontSize:"12px"}}>kajoldash28@gmail.com</div>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
               < div className="col-sm-9 offset-sm-2 panel panel-default">
                    <div className="panel-heading" style={{ backgroundColor: "#bcbdbf", padding: "1px" }}>
                    <h4 style={{ padding: "0px 15px", fontSize: "16px",fontWeight:"600", marginTop: "13px", color: "#333" }}>My looks</h4>
                    </div>
                    <div className="panel-body">
                
                <div className="col-sm-12 cardpage">
                    <div className="row">
                        {(ProfileState.length !== 0) ?
                            ProfileState.map((value, i) =>
                                <div className="col-sm-3 " style={{ marginBottom: "20px", marginLeft: "3px" }} >
                                    <div className="row">
                                        <div className="col-sm-12 zoom" style={{ margin: "10px" }}>

                                            <img src={ProfileState[i].author.profile_pic.medium} className="productimg" alt="image not available" style={{ width: "100%" }} />
                                        </div>


                                    </div>
                                </div>
                            )
                            :
                            <div>No Records</div>

                        }

                    </div>
                </div>

            </div>
            </div>

            </div>
        )

    }
}
const HomePage = connect(mapStateToProps, mapDispatchToProps)(HomePageComp)
export default HomePage
